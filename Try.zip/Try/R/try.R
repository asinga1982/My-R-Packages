#' Distance Finder
#'
#' This function can be used to find km distance between 2 places.
#'
#' @param long1 Longitude of the first place
#' @param lat1  Lattitude of the first place
#' @param long2 Longitude of the second place
#' @param lat2  Lattitude of the second place
#' @return Disctance in km
#' @author Aanish
#' @details
#' This function can be used to find km distance between 2 places using
#' the distm function.
#' @seealso \code{distm}
#' @export
#' @importFrom geosphere distm

try <- function(long1, lat1, long2, lat2) {
  distm(c(long1, lat1), c(long2, lat2))/1000
}
